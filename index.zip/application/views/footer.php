<div class="row ">
    <div class="col-md-12 text-center mt-5  shadow-sm p-md-2 mb-2 border">
        SaidUnsaid@2020
    </div>
  </div>

<!-- END OF CONTAINER-->
</div>


<div id="modalMSG" class="modal fade" role="dialog">
  <div class="modal-dialog modal-dialog-centered">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="modalMSGTitle"></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body" id="modalMSGBody">
        <p></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</body>

</html>